<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Controle de Despesas - Pesquisa</title>
</head>
<body>
    <?php
        require "menu.php";
    echo "<h3>Listagem dos Clientes</h3>";
    require "conexao.php";
    $sql="SELECT * FROM contas ORDER BY data";
    $resultado=mysqli_query($conexao, $sql) or die(mysqli_error($conexao));
    echo "<table border='1' width='1000' align='center'>";
        echo "<tr>";
        echo "<th width='100' align='right'>Lançamento</th>";
        echo "<th width='100' align='right'>Código</th>";
        echo "<th width='300' align='left'>Data</th>";
        echo "<th width='100' align='left'>Valor</th>";
        echo "<th width='250' align='left'>historico</th>";
        echo "<th width='50' align='left'>Editar</th>";
    echo "</tr>";
    while($linha=mysqli_fetch_array($resultado)) 
    {
        $lancamento = $linha["lancamento"];
        $codigo =  $linha["codigo_cliente"];
        $data   =  $linha["data"];
        $valor    =  $linha["valor"];
        $historico  =  $linha["historico"];

        echo "<tr>";
        echo "<td width='100'align='right'>$lancamento</td>";
        echo "<td width='100'align='right'>$codigo</td>";
        echo "<td width='300'align='right'>$data</td>";
        echo "<td width='100'align='right'>$valor</td>";
        echo "<td width='250'align='right'>$historico</td>";
        echo "<td width='50'><a href='contas_editar.php?lancamento=$lancamento'>Editar</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    
    ?>
    </body>
</html>