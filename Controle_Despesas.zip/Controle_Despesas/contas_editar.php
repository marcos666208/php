<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Controle de Despesas - Editar Contas</title>
    <link rel="stylesheet" href="estilos_menu.css">
    <link rel="stylesheet" href="estilos_formulario.css">
</head>
<body>
    <?php
        require "menu.php";

        echo "<h3>Editar Cadastro de Clientes</h3>";
        
        require "conexao.php";
        $lancamento = $_REQUEST["lancamento"];
        $sql = "SELECT * FROM contas WHERE lancamento='$lancamento'";
        $resultado = mysqli_query($conexao, $sql) or die(mysqli_error($conexao));
        $linha = mysqli_fetch_array($resultado);

        $lancamento = $linha["lancamento"];
        $codigo_cliente = $linha["codigo_cliente"];
        $data = $linha["data"];
        $historico = $linha["historico"];
        $valor = $linha["valor"];
        

        echo "<form name='cadastro' method='post' action=''>";
            echo "<table align='center'>";
                echo "<tr>";
                    echo "<td><label for='Código'>Código:</label></td>";
                    echo "<td><input type='number' name='codigo' size='4' value='$codigo_cliente' readonly></td>";
                echo "</tr>";
                echo "<tr>";
                    echo "<td><label for='data'>Data:</label></td>";
                    echo "<td><input type='date' name='nome' size='50' maxlegth='50' value='$data' required></td>";
                echo "</tr>";
                echo "<tr>";
                    echo "<td><label for='historico'>Historico:</label></td>";
                    echo "<td><input type='text' name='historico' size='30' maxlegth='30' value='$historico' required></td>";
                echo "</tr>";
                echo "<tr>";
                    echo "<td><label for='valor'>Valor:</label></td>";
                    echo "<td><input type='number' name='valor' size='14' maxlegth='14' value='$valor' required></td>";
                echo "</tr>";
                echo "<tr>";
                    echo "<td colspan='2' align='center'><input type='submit' name='salvar' value='Salvar'></td>";
                echo "</tr>";
            echo "</table>";
        echo "</form>";

        if (isset($_POST["salvar"])) {
            $lan = $_POST["lancamento"];
            $codigo_cliente = $_POST["codigo_cliente"];
            $data = $_POST["data"];
            $historico = $_POST["historico"];
            $valor = $_POST["valor"];

            require "conexao.php";
            $sql = "UPDATE contas SET codigo_cliente='$codigo_cliente', data='$data', historico='$historico', valor='$valor' WHERE lancamento='$lan'";
            mysqli_query($conexao, $sql) or die(mysqli_error($conexao));
            echo "<script type =\"text/javascript\">alert('Cliente editado com sucesso!');</script>";
            echo "<p align='center'><a href='home.php'>Voltar</a></p>";
        }
    ?>
</body>
</html>